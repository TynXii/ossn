People below helped in many ways to improve the code:

- Michael Zülsdorff https://www.opensource-socialnetwork.org/u/zetman
- Arsalan Shah https://github.com/lianglee
- Rafael Amorim https://github.com/rafaelmamorim