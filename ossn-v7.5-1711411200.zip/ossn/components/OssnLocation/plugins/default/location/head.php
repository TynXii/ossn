<script>
Ossn.LocationAPIKey = '<?php echo ossn_location_api_key(); ?>';
</script>