<div class="row message-none">
    <div class="col-lg-12"> <?php echo ossn_print('no:messages'); ?></div>
</div>
